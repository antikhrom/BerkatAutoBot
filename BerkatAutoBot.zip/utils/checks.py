def check_vin(vin: str) -> dict:
    return {"vin": vin, "status": "OK", "history": "Clean"}
